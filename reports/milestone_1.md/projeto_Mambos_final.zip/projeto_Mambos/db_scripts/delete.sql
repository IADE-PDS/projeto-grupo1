drop table compra;
drop table item;
drop table shoplist;
drop table lojaproduto;
drop table loja;
drop table produto;
drop table appuser;
drop table localizacoes;